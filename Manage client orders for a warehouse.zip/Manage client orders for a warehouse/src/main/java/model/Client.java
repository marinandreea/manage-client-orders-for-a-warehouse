package model;

/**
 * Class for objects of type client
 */
public class Client {

    private int clientID;
    private String firstName;
    private String lastName;
    private String email;
    private String phoneNumber;

    /**
     * @param clientID id of the client
     * @param firstName first name of the client
     * @param lastName last name of the client
     * @param email email of the client
     * @param phoneNumber phone number of the client
     *
     *  Constructor used to create objects of type client
     */
    public Client(int clientID, String firstName, String lastName, String email, String phoneNumber) {
        this.clientID = clientID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.phoneNumber = phoneNumber;
    }

    /**
     * @return  id of the client
     */
    public int getClientID() {
        return clientID;
    }

    /**
     * @return  first name of the client
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * @param firstName first name of the client
     *
     *  The method sets the first name of the client
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * @return last name of the client
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * @param lastName last name of the client
     *
     *  The method sets the last name of the client
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * @param email email of the client
     *
     * The method sets the email of the client
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @param phoneNumber phone number of the client
     *
     * The method sets the phone number of the client
     */
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
}
