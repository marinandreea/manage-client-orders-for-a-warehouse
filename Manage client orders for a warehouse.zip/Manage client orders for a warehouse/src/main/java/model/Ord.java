package model;

/**
 * Class for objects of type order
 */
public class Ord {

    private int orderID;
    private int clientId;
    private int productId;
    private int quantity;
    private String city;
    private String street;

    /**
     * @param orderID id of the order
     * @param clientId id of the client making that order
     * @param productId id of the product ordered
     * @param quantity quantity of the product
     * @param city city where to deliver
     * @param street street where to deliver
     */
    public Ord(int orderID, int clientId, int productId, int quantity, String city, String street) {
        this.orderID = orderID;
        this.clientId = clientId;
        this.productId = productId;
        this.quantity = quantity;
        this.city = city;
        this.street = street;
    }

    /**
     * @return id of the order
     */
    public int getOrderID() {
        return orderID;
    }

    /**
     * @return id of the client making the order
     */
    public int getClientId() {
        return clientId;
    }

    /**
     * @return id of the product ordered
     */
    public int getProductId() {
        return productId;
    }

    /**
     * @return quantity of the product
     */
    public int getQuantity() {
        return quantity;
    }

}
