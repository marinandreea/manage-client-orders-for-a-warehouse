package model;

/**
 * Class for objects of type product
 */
public class Product {

    private int productID;
    private String productName;
    private double price;
    private int nrStock;

    /**
     * @param productID id of the product
     * @param productName name of the product
     * @param price price of the product
     * @param nrStock stock of the product
     *
     * Constructor used to create objects of type product
     */
    public Product(int productID, String productName, double price, int nrStock) {
        this.productID = productID;
        this.productName = productName;
        this.price = price;
        this.nrStock = nrStock;
    }

    /**
     * @return id of the product
     */
    public int getProductID() {
        return productID;
    }

    /**
     * @return name of the product
     */
    public String getProductName() {
        return productName;
    }

    /**
     * @param productName name of the product
     *
     * The method sets the name of the product
     */
    public void setProductName(String productName) {
        this.productName = productName;
    }

    /**
     * @return price of the product
     */
    public double getPrice() {
        return price;
    }

    /**
     * @param price price of the product
     *
     * The method sets the price of the product
     */
    public void setPrice(double price) {
        this.price = price;
    }

    /**
     * @return nrStock of the product
     */
    public int getNrStock() {
        return nrStock;
    }

    /**
     * @param nrStock nrStock of the product
     *
     * The method sets the nrStock of the product
     */
    public void setNrStock(int nrStock) {
        this.nrStock = nrStock;
    }
}
