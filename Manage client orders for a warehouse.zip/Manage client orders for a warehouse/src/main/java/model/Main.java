package model;

import connection.ConnectionFactory;
import presentation.Controller;
import presentation.ClientInterface;
import presentation.OrInterface;
import presentation.ProductInterface;
import presentation.UserInterface;

import java.sql.Connection;

/**
 * Class that starts the application
 */
public class Main {

    public static void main(String[] args){

        Connection connection = ConnectionFactory.getConnection();
        UserInterface userInterface;
        ClientInterface clientInterface;
        ProductInterface productInterface;
        OrInterface orInterface;
        userInterface = new UserInterface();
        clientInterface = new ClientInterface(userInterface,connection);
        productInterface = new ProductInterface(userInterface, connection);
        orInterface = new OrInterface(userInterface, connection, productInterface, clientInterface);
        Controller c = new Controller(userInterface,clientInterface,productInterface, orInterface);
        userInterface.setVisible(true);
    }
}
