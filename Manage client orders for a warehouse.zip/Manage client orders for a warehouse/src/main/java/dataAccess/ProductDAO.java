package dataAccess;

import businessLogic.ValidatorProduct;
import model.Product;
import presentation.ProductInterface;

import javax.swing.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 * Class that extends the GenericDAO and uses the generic methods to implement insert, delete, update and show table for product
 */
public class ProductDAO extends GenericDAO<Product>{


    private static Connection connection;
    private ProductInterface productInterface;
    private Statement productStatement;

    /**
     * @param connect connection to the product table form the database
     * @param productInterf product interface
     */
    public ProductDAO(Connection connect, ProductInterface productInterf){
        this.connection = connect;
        this.productInterface = productInterf;
        try{
            this.productStatement = connect.createStatement();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

    }

    /**
     * @return an ArrayList containing the products form the table
     *
     * @throws SQLException can be thrown
     */
    public ArrayList<Product> prodArray() throws SQLException {

        ArrayList<Product> list = new ArrayList<Product>();
        ResultSet rs = productStatement.executeQuery("SELECT * FROM product");
        while(rs.next()){
            Product p = new Product(rs.getInt("productID"),rs.getString("productName"), rs.getInt("price"),rs.getInt("nrStock"));
            list.add(p);
        }
        return list;
    }

    /**
     * Method that calls the createTable and creates the table with products
     *
     * @throws SQLException can be thrown
     */
    public void printProducts() throws SQLException {

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(10, 215, 735, 235);
        JTable table = new JTable();
        ArrayList<Product> list = new ArrayList<Product>();
        list = prodArray();
        table = createTable(list);
        table.setEnabled(true);
        table.setVisible(true);
        scrollPane.setViewportView(table);
        productInterface.add(scrollPane);
    }

    /**
     * Method that calls the generic method insert in order to insert a new product in the table
     *
     * @throws SQLException can be thrown
     */
    public void insertProduct() throws SQLException {

        String productID = productInterface.getProductIDTxtField().getText();
        String productName = productInterface.getProductNameTxtField().getText();
        String priceProduct = productInterface.getPriceTxtField().getText();
        String nrStockProduct = productInterface.getStockTxtField().getText();
        ValidatorProduct val = new ValidatorProduct();
        ArrayList<Product> l;
        int pr = Integer.parseInt(productID);
        try{
            if(val.validateProduct(productName, Double.parseDouble(priceProduct), Integer.parseInt(nrStockProduct))){
                Product newP = new Product(pr, productName, Double.parseDouble(priceProduct), Integer.parseInt(nrStockProduct));
                insert(newP);
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Bad input!");
        }
    }

    /**
     * Method that calls the generic method delete in order to delete the product with the given id
     *
     * @throws SQLException can be thrown
     */
    public void deleteProduct() throws SQLException {
        String productID = productInterface.getProductIDTxtField().getText();
        ArrayList<Product> l = null;
        int pr = Integer.parseInt(productID);;

        try{
            Product product = null;
            l=prodArray();
            for(Product p: l){
                if(p.getProductID() == pr){
                    product=p;
                }
            }
            if(product != null){
                delete(product);
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Bad input!");
        }
    }

    /**
     * Method that calls the generic method update in order to update an already existing product
     *
     * @throws SQLException can be thrown
     */
    public void updateProduct() throws SQLException {
        String productID = productInterface.getProductIDTxtField().getText();
        String productName = productInterface.getProductNameTxtField().getText();
        String priceProduct = productInterface.getPriceTxtField().getText();
        String nrStockProduct = productInterface.getStockTxtField().getText();
        ValidatorProduct val = new ValidatorProduct();
        ArrayList<Product> l;
        int pr = Integer.parseInt(productID);


        try{
            if(val.validateProduct(productName, Double.parseDouble(priceProduct), Integer.parseInt(nrStockProduct))){
                Product product = null;
                l = prodArray();
                for(Product p: l){
                    if(p.getProductID() == pr){
                        product=p;
                    }
                }
                if(product != null){
                    product.setProductName(productName);
                    product.setPrice(Double.parseDouble(priceProduct));
                    product.setNrStock(Integer.parseInt(nrStockProduct));
                    update(product);
                }
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Bad input!");
        }
    }
}
