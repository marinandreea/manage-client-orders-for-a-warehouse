package dataAccess;

import connection.ConnectionFactory;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.lang.reflect.Field;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * @param <T> T can be any Java Model Class that is
 * mapped to the Database, and has the same name as the table and the same instance variables and data types as
 * the table fields
 */
public class GenericDAO<T> {


    /**
     * @param obj obj can be a client, product or order
     *
     * The method creates the corresponding query for insertion and executes it
     */
    public void insert(Object obj){

        StringBuilder query = new StringBuilder();
        StringBuilder values = new StringBuilder();
        Field[] fields = obj.getClass().getDeclaredFields();
        query.append("INSERT INTO " + obj.getClass().getSimpleName() + "(");
        try{
            for(int i = 0;i < fields.length; i++){

                fields[i].setAccessible(true);
                Object v = fields[i].get(obj);

                if(i != fields.length - 1){

                   query.append(fields[i].getName()).append(", ");
                   if(fields[i].getType().getSimpleName().equals("String")){
                    values.append("'").append(v).append("'").append(", ");
                   }else{
                    values.append(v).append(", ");
                   }
                }else{
                      query.append(fields[i].getName());
                      if(fields[i].getType().getSimpleName().equals("String")){
                        values.append("'").append(v).append("'");
                      }else{
                        values.append(v);
                      }
                }
            }
            query.append(") VALUES " + " (").append(values).append(");");
            System.out.println(query.toString());
        }catch (IllegalAccessException e) {
            JOptionPane.showMessageDialog(null, "Error at inserting");
        }
        try{
            Connection connection = ConnectionFactory.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(query.toString());
            preparedStatement.executeUpdate();
            ConnectionFactory.close(connection);
            ConnectionFactory.close(preparedStatement);
            JOptionPane.showMessageDialog(null, "Record created successfully!");
        } catch (Exception e) {
            //JOptionPane.showMessageDialog(null, "Exception when executing insert query");
        }
    }


    /**
     * @param obj obj can be a client, product or order
     *
     * The method creates the corresponding query for deletion and executes it
     */
    public void delete(Object obj){

        StringBuilder query = new StringBuilder();
        Field[] fields = obj.getClass().getDeclaredFields();
        fields[0].setAccessible(true);
        query.append("DELETE FROM " + obj.getClass().getSimpleName() + " WHERE " );
        query.append(fields[0].getName()).append("=");
        try{
            Object v = fields[0].get(obj);
            query.append(v).append(";");
        } catch (IllegalAccessException e) {
            JOptionPane.showMessageDialog(null, "Error at getting id value");
        }
        try{
            Connection connection = ConnectionFactory.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(query.toString());
            preparedStatement.executeUpdate();
            ConnectionFactory.close(connection);
            ConnectionFactory.close(preparedStatement);
            JOptionPane.showMessageDialog(null, "Record deleted successfully!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Exception when executing delete query");
        }

    }

    /**
     * @param obj obj can be a client, product or order
     *
     * The method creates the corresponding query for update and executes it
     */
    public void update(Object obj){

        StringBuilder query = new StringBuilder();
        Field[] fields = obj.getClass().getDeclaredFields();
        query.append("UPDATE " + obj.getClass().getSimpleName() + " SET ");
        try{
            for(int i = 0;i < fields.length; i++){

                fields[i].setAccessible(true);
                Object v = fields[i].get(obj);
                query.append(fields[i].getName()).append("=");
                if(i != fields.length - 1){
                    if(fields[i].getType().getSimpleName().equals("String")){
                        query.append("'").append(v).append("'").append(", ");
                    }else{
                        query.append(v).append(", ");
                    }
                }else{
                    if(fields[i].getType().getSimpleName().equals("String")){
                        query.append("'").append(v).append("'");
                    }else{
                        query.append(v);
                    }
                }
            }
            query.append(" WHERE ");
            fields[0].setAccessible(true);
            query.append(fields[0].getName()).append("=");
            Object v = fields[0].get(obj);
            query.append(v + ";");
        } catch (IllegalAccessException e) {
            JOptionPane.showMessageDialog(null, "Error at updating");
        }
        try{
            Connection connection = ConnectionFactory.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(query.toString());
            preparedStatement.executeUpdate();
            ConnectionFactory.close(connection);
            ConnectionFactory.close(preparedStatement);
            JOptionPane.showMessageDialog(null, "Record updated successfully!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Exception when executing update query");
        }
        }

    /**
     * @param myList list can be of type client, product or order
     * @return a JTable containing the elements of the list
     */
    public static JTable createTable(ArrayList<?> myList) {
        int tableSize = myList.get(0).getClass().getDeclaredFields().length;
        String columnNames[] = new String[tableSize];
        int columnIndex = 0;
        for (java.lang.reflect.Field currentField : myList.get(0).getClass().getDeclaredFields()) {
            currentField.setAccessible(true);
            try {
                columnNames[columnIndex] = currentField.getName();
                columnIndex++;
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
            }
        }
        DefaultTableModel myModel = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;// all cells false
            }
        };
        myModel.setColumnIdentifiers(columnNames);
        for (Object o : myList) {
            Object[] obj = new Object[tableSize];
            int col = 0;
            for (java.lang.reflect.Field currentField : o.getClass().getDeclaredFields()) {
                currentField.setAccessible(true);
                try {
                    obj[col] = currentField.get(o);
                    col++;
                } catch (IllegalArgumentException | IllegalAccessException e) {
                    e.printStackTrace();
                }
            }
            myModel.addRow(obj);
        }
        JTable myTable = new JTable(myModel);
        return myTable;
    }
}



