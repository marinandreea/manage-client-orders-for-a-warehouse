package dataAccess;

import businessLogic.ValidatorClient;
import connection.ConnectionFactory;
import model.Client;
import presentation.ClientInterface;

import javax.swing.*;
import java.sql.*;
import java.util.ArrayList;

/**
 * Class that extends the GenericDAO and uses the generic methods to implement insert, delete, update and show table for client
 */
public class ClientDAO extends GenericDAO<Client> {

    private ClientInterface clientInterface;
    private Statement clientStatement;
    private Connection clientConnection;


    /**
     * @param clientConnection connection to the client table form the database
     * @param clientInterface client interface
     */
    public ClientDAO(Connection clientConnection, ClientInterface clientInterface){
        this.clientConnection = clientConnection;
        this.clientInterface = clientInterface;
        try{
            this.clientStatement = clientConnection.createStatement();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    /**
     * @return an ArrayList containing the clients form the table
     *
     * @throws SQLException  can be thrown
     */
    public ArrayList<Client> clientArray() throws SQLException {

        ArrayList<Client> list = new ArrayList<Client>();
        ResultSet rs = clientStatement.executeQuery("SELECT * FROM client");
        while(rs.next()){
            Client c = new Client(rs.getInt("clientID"),rs.getString("firstName"),rs.getString("lastName"),rs.getString("email"), rs.getString("phoneNumber"));
            list.add(c);
        }
        return list;
    }

    /**
     * Method that calls the createTable and creates the table with clients
     *
     * @throws SQLException  can be thrown
     */
    public void printClients() throws SQLException {

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(10, 215, 735, 235);
        JTable table = new JTable();
        ArrayList<Client> list = new ArrayList<Client>();
        list=clientArray();
        table = createTable(list);
        table.setEnabled(true);
        table.setVisible(true);
        scrollPane.setViewportView(table);
        clientInterface.add(scrollPane);
    }

    /**
     * Method that calls the generic method insert in order to insert a new client in the table
     *
     * @throws SQLException  can be thrown
     *
     */
    public void insertClient() throws SQLException {

        String clientID = clientInterface.getClientIDTxtField().getText();
        String clientFirstName = clientInterface.getFirstNameTxtField().getText();
        String clientLastName = clientInterface.getLastNameTxtField().getText();
        String emailClient = clientInterface.getEmailTxtField().getText();
        String phoneClient = clientInterface.getPhoneNrTxtField().getText();
        ValidatorClient val = new ValidatorClient();
        int cl = Integer.parseInt(clientID);

        try{
        if(val.validatorClient(clientFirstName, clientLastName, emailClient, phoneClient)){
            Client newC = new Client(cl, clientFirstName, clientLastName, emailClient,phoneClient);
            insert(newC);
        }

        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Bad input!");
        }

    }

    /**
     * Method that calls the generic method delete in order to delete the client with the given id
     *
     * @throws SQLException can be thrown
     */
    public void deleteClient() throws SQLException {
        String clientID = clientInterface.getClientIDTxtField().getText();
        int cl = Integer.parseInt(clientID);
        try{
            Client client = null;
            ArrayList<Client> list = new ArrayList<Client>();
           list=clientArray();
            for(Client c: list){
                if(c.getClientID() == cl){
                    client=c;
                }
            }
            if(client != null){
                delete(client);
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Bad input!");
        }
    }

    /**
     * Method that calls the generic method update in order to update an already existing client
     *
     * @throws SQLException can be thrown
     */
    public void updateClient() throws SQLException {
        String clientID = clientInterface.getClientIDTxtField().getText();
        String clientFirstName = clientInterface.getFirstNameTxtField().getText();
        String clientLastName = clientInterface.getLastNameTxtField().getText();
        String emailClient = clientInterface.getEmailTxtField().getText();
        String phoneClient = clientInterface.getPhoneNrTxtField().getText();
        ValidatorClient val = new ValidatorClient();
        int cl = Integer.parseInt(clientID);
        try{
            if(val.validatorClient(clientFirstName, clientLastName, emailClient, phoneClient)){
                Client client = null;
                ArrayList<Client> list = new ArrayList<Client>();
                list=clientArray();
                for(Client c: list){
                    if(c.getClientID() == cl){
                        client=c;
                    }
                }
                if(client != null){
                    client.setFirstName(clientFirstName);
                    client.setLastName(clientLastName);
                    client.setEmail(emailClient);
                    client.setPhoneNumber(phoneClient);
                    update(client);
                }
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Bad input!");
        }

    }
}
