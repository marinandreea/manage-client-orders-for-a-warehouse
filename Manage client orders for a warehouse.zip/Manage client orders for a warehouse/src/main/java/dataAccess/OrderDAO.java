package dataAccess;

import businessLogic.ValidatorOrder;
import connection.ConnectionFactory;
import model.Ord;
import model.Product;
import presentation.OrInterface;
import presentation.ProductInterface;


import javax.swing.*;
import java.sql.*;
import java.util.ArrayList;

/**
 * Class that extends the GenericDAO and uses the generic methods to implement insert, delete, update and show table for order
 */
public class OrderDAO extends GenericDAO<Ord>{

    private static Connection connection;
    private OrInterface orInterface;
    private ProductInterface productInterface;
    private Statement orderStatement;

    /**
     * @param connect connection to the order table form the database
     * @param orderInterf order interface
     * @param prodInterface product interface
     */
    public OrderDAO(Connection connect, OrInterface orderInterf, ProductInterface prodInterface){
        this.connection = connect;
        this.orInterface = orderInterf;
        this.productInterface = prodInterface;
        try{
            this.orderStatement = connect.createStatement();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    /**
     * @return an ArrayList containing the orders form the table
     *
     * @throws SQLException can be thrown
     */
    public ArrayList<Ord> orderArray() throws SQLException {

        ArrayList<Ord> list = new ArrayList<Ord>();
        ResultSet rs = orderStatement.executeQuery("SELECT * FROM ord");
        while(rs.next()){
            Ord o = new Ord(rs.getInt("orderID"),rs.getInt("clientId"),rs.getInt("productId"),rs.getInt("quantity"), rs.getString("city"),rs.getString("street"));
            list.add(o);
        }
        return list;
    }

    /**
     * Method that calls the createTable and creates the table with orders
     *
     * @throws SQLException can be thrown
     */
    public void printOrders() throws SQLException {

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(5, 240, 740, 300);
        JTable table = new JTable();
        ArrayList<Ord> list = new ArrayList<Ord>();
        list = orderArray();
        table = createTable(list);
        table.setEnabled(true);
        table.setVisible(true);
        scrollPane.setViewportView(table);
        orInterface.add(scrollPane);
    }

    /**
     * Method that calls the generic method insert in order to insert a new order in the table
     *
     * @throws SQLException can be thrown
     */
    public void createOrder() throws SQLException {

        String orderID = orInterface.getOrderIDTxtField().getText();
        int clientId = orInterface.getClientID();
        int productId = orInterface.getProductID();
        String quantity = orInterface.getQuantityTxtField().getText();
        String city = orInterface.getCityTxtField().getText();
        String street = orInterface.getStreetTxtField().getText();
        ValidatorOrder val = new ValidatorOrder();
        ArrayList<Ord> l;
        int or = Integer.parseInt(orderID);
        try{
            if(val.validateOrder(Integer.parseInt(quantity),city,street)){
               ProductDAO productDAO = new ProductDAO(connection, productInterface);
                ArrayList<Product> l2;
                Product product = null;
                l2=productDAO.prodArray();
                for(Product p: l2){
                    if(p.getProductID() == productId){
                        product=p;
                    }
                }
                if(product != null){
                    if(Integer.parseInt(quantity) <= product.getNrStock()){
                        product.setNrStock(product.getNrStock() - Integer.parseInt(quantity));
                        update(product);
                        Ord newOrder = new Ord(Integer.parseInt(orderID),clientId, productId, Integer.parseInt(quantity),city,street);
                        insert(newOrder);
                    }else{
                        JOptionPane.showMessageDialog(null, "Quantity bigger than stock!");
                    }
                }
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Bad input!");
        }
    }

    /**
     * @return an ArrayList containing the ids of clients
     */
    public ArrayList<Integer> listClientID(){

        ArrayList<Integer> listIds = new ArrayList<Integer>();
        Connection connection = ConnectionFactory.getConnection();
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        String q = "SELECT clientID FROM client";
        try{
            preparedStatement = connection.prepareStatement(q);
            rs = preparedStatement.executeQuery();
            //listIds.add(rs.getInt("clientID"));
            while(rs.next()){
                listIds.add(rs.getInt("clientID"));
            }
            ConnectionFactory.close(preparedStatement);
            ConnectionFactory.close(rs);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return listIds;
    }

    /**
     * @return an ArrayList containing the ids of products
     */
    public ArrayList<Integer> listProductID(){

        ArrayList<Integer> listIds = new ArrayList<Integer>();
        Connection connection = ConnectionFactory.getConnection();
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        String q = "SELECT productID FROM product";
        try{
            preparedStatement = connection.prepareStatement(q);
            rs = preparedStatement.executeQuery();
            while(rs.next()){
                listIds.add(rs.getInt("productID"));
            }
            ConnectionFactory.close(preparedStatement);
            ConnectionFactory.close(rs);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return listIds;
    }

}
