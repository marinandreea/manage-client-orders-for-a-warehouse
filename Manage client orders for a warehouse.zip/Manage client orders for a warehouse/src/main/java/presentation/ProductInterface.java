package presentation;

import dataAccess.ProductDAO;

import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import javax.swing.*;
import javax.swing.event.*;

/**
 * Class that implements the graphical user interface for managing the product table
 */
public class ProductInterface extends JFrame {
    private JLabel productIDLabel;
    private JTextField productIDTxtField;
    private JLabel productNameLabel;
    private JTextField productNameTxtField;
    private JLabel priceLabel;
    private JTextField priceTxtField;
    private JLabel stockLabel;
    private JTextField stockTxtField;
    private JTextArea productTxtArea;
    private JButton showTableButton;
    private JButton insertButton;
    private JButton deleteButton;
    private JButton updateButton;
    private JButton backButton;
    private JButton clearButton;

    /**
     * @param userInterface userInterface
     * @param con connection to the table product from the database
     *
     * The method establishes the connection to the product table form the database, initializes the labels, text fields and buttons,
     * sets their bounds and adds them to the frame
     */
    public ProductInterface(UserInterface userInterface, Connection con) {

        ProductInterface cInt = this;
        ProductDAO productDAO = new ProductDAO(con, cInt);

        this.setTitle("Product Table");
        this.setSize(900, 900);
        this.setLayout((LayoutManager)null);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setVisible(true);

        //construct components
        productIDLabel = new JLabel ("Product ID:");
        productIDTxtField = new JTextField (5);
        productNameLabel = new JLabel ("Product Name:");
        productNameTxtField = new JTextField (5);
        priceLabel = new JLabel ("Price:");
        priceTxtField = new JTextField (5);
        stockLabel = new JLabel ("Stock:");
        stockTxtField = new JTextField (5);
        productTxtArea = new JTextArea (5, 5);
        showTableButton = new JButton ("Show Tabel");
        insertButton = new JButton ("Insert");
        deleteButton = new JButton ("Delete");
        updateButton = new JButton ("Update");
        backButton = new JButton ("Back");
        clearButton = new JButton ("Clear");

        //adjust size and set layout
        setPreferredSize (new Dimension (752, 457));
        setLayout (null);

        //add components
        add (productIDLabel);
        add (productIDTxtField);
        add (productNameLabel);
        add (productNameTxtField);
        add (priceLabel);
        add (priceTxtField);
        add (stockLabel);
        add (stockTxtField);
        add (productTxtArea);
        add (showTableButton);
        add (insertButton);
        add (deleteButton);
        add (updateButton);
        add (backButton);
        add (clearButton);

        //set component bounds (only needed by Absolute Positioning)
        productIDLabel.setBounds (10, 20, 70, 25);
        productIDTxtField.setBounds (85, 20, 100, 25);
        productNameLabel.setBounds (10, 60, 90, 25);
        productNameTxtField.setBounds (100, 60, 135, 25);
        priceLabel.setBounds (10, 100, 70, 25);
        priceTxtField.setBounds (85, 100, 100, 25);
        stockLabel.setBounds (10, 140, 70, 25);
        stockTxtField.setBounds (85, 140, 100, 25);
        productTxtArea.setBounds (10, 215, 735, 235);
        showTableButton.setBounds (400, 20, 100, 25);
        insertButton.setBounds (565, 20, 100, 25);
        deleteButton.setBounds (400, 70, 100, 25);
        updateButton.setBounds (565, 70, 100, 25);
        backButton.setBounds (565, 120, 100, 25);
        clearButton.setBounds (400, 120, 100, 25);
    }

    /**
     * @return id of the product introduced in the corresponding text field
     */
    public JTextField getProductIDTxtField() {
        return productIDTxtField;
    }

    /**
     * @return name of the product introduced in the corresponding text field
     */
    public JTextField getProductNameTxtField() {
        return productNameTxtField;
    }

    /**
     * @return price of the product introduced in the corresponding text field
     */
    public JTextField getPriceTxtField() {
        return priceTxtField;
    }

    /**
     * @return stock of the product introduced in the corresponding text field
     */
    public JTextField getStockTxtField() {
        return stockTxtField;
    }

    /**
     * @param e action performed
     *
     * The method adds the listener for insert button
     */
    public void addListenerInsertBtn(ActionListener e) {
        this.insertButton.addActionListener(e);
    }

    /**
     * @param e action performed
     *
     * The method adds the listener for delete button
     */
    public void addListenerDeleteBtn(ActionListener e) {
        this.deleteButton.addActionListener(e);
    }

    /**
     * @param e action performed
     *
     * The method adds the listener for update button
     */
    public void addListenerUpdateBtn(ActionListener e) {
        this.updateButton.addActionListener(e);
    }

    /**
     * @param e action performed
     *
     * The method adds the listener for show table button
     */
    public void addListenerShowTableBtn(ActionListener e) {
        this.showTableButton.addActionListener(e);}

    /**
     * @param e action performed
     *
     * The method adds the listener for back button
     */
    public void addListenerBackBtn(ActionListener e) {
        this.backButton.addActionListener(e);
    }

    /**
     * @param e action performed
     *
     * The method adds the listener for clear button
     */
    public void addListenerClearBtn(ActionListener e) {
        this.clearButton.addActionListener(e);
    }

}
