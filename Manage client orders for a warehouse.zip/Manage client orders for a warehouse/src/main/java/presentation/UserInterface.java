package presentation;


import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

/**
 * The main frame which is the mother of all the other frames in this application
 */
public class UserInterface extends JFrame {
    private JLabel titleLabel;
    private JButton clientTableButton;
    private JButton productTableButton;
    private JButton orderTableButton;

    /**
     * Constructor which initializes the buttons, sets their bounds and adds them to the frame
     */
    public UserInterface() {

        this.setTitle("Database Management Table");
        this.setSize(900, 900);
        this.setLayout((LayoutManager)null);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setVisible(true);

        //construct components
        titleLabel = new JLabel ("DATABASE MANAGEMENT SYSTEM");
        clientTableButton = new JButton ("Manage Client Table");
        productTableButton = new JButton ("Manage Product Table");
        orderTableButton = new JButton ("Manage Order Table");

        //adjust size and set layout
        setPreferredSize (new Dimension (752, 457));
        setLayout (null);

        //add components
        add (titleLabel);
        add (clientTableButton);
        add (productTableButton);
        add (orderTableButton);

        //set component bounds (only needed by Absolute Positioning)
        titleLabel.setBounds (260, 55, 320, 40);
        clientTableButton.setBounds (275, 145, 180, 35);
        productTableButton.setBounds (275, 235, 180, 35);
        orderTableButton.setBounds (275, 325, 180, 35);
    }

    /**
     * @param e action performed
     *
     * The method adds the listener for client table
     */
    public void addListenerClientBtn(ActionListener e) {
        this.clientTableButton.addActionListener(e);
    }

    /**
     * @param e action performed
     *
     * The method adds the listener for product table
     */
    public void addListenerProductBtn(ActionListener e) {
        this.productTableButton.addActionListener(e);
    }

    /**
     * @param e action performed
     *
     * The method adds the listener for order table
     */
    public void addListenerOrderBtn(ActionListener e) {
        this.orderTableButton.addActionListener(e);
    }

}
