package presentation;

import dataAccess.OrderDAO;

import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.util.ArrayList;
import javax.swing.*;

/**
 * Class that implements the graphical user interface for managing the order table
 */
public class OrInterface extends JFrame {

    private JLabel orderIDLabel;
    private JTextField orderIDTxtField;
    private JLabel clientIDLabel;
    private JComboBox<Integer> clientIDComboBox;
    private JLabel productIDLabel;
    private JComboBox<Integer> productIDComboBox;
    private JLabel quantityLabel;
    private JTextField quantityTxtField;
    private JTextArea orderTxtArea;
    private JButton showTableButton;
    private JButton insertButton;
    private JButton generateBillButton;
    private JButton backButton;
    private JButton clearButton;
    private JLabel cityLabel;
    private JTextField cityTxtField;
    private JLabel streetLabel;
    private JTextField streetTxtField;

    /**
     * @param userInterface userInterface
     * @param connection connection to the table product from the database
     * @param productInterface productInterface
     * @param clientInterface clientInterface
     *
     * The method establishes the connection to the order table form the database, initializes the labels, text fields and buttons,
     * sets their bounds and adds them to the frame
     */
    public OrInterface(UserInterface userInterface, Connection connection, ProductInterface productInterface, ClientInterface clientInterface) {

        this.setTitle("Order Table");
        this.setSize(900, 900);
        this.setLayout((LayoutManager)null);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setVisible(true);

        OrInterface orInterface = this;
        OrderDAO order = new OrderDAO(connection, orInterface, productInterface);

        //construct components
        orderIDLabel = new JLabel ("Order ID:");
        orderIDTxtField = new JTextField (5);
        clientIDLabel = new JLabel ("Client ID:");
        clientIDComboBox = new JComboBox<>();
        productIDLabel = new JLabel ("Product ID:");
        productIDComboBox = new JComboBox<>();
        quantityLabel = new JLabel ("Quantity:");
        quantityTxtField = new JTextField (5);
        orderTxtArea = new JTextArea (5, 5);
        showTableButton = new JButton ("Show Tabel");
        insertButton = new JButton ("Insert");
        generateBillButton = new JButton ("Generate Bill");
        backButton = new JButton ("Back");
        clearButton = new JButton ("Clear");
        cityLabel = new JLabel ("City:");
        cityTxtField = new JTextField (5);
        streetLabel = new JLabel ("Street:");
        streetTxtField = new JTextField (5);

        //adjust size and set layout
        setPreferredSize (new Dimension (752, 457));
        setLayout (null);

        ArrayList<Integer> a1 = new ArrayList<Integer>();
        ArrayList<Integer> a2 = new ArrayList<Integer>();
        a1 = order.listClientID();
        a2 = order.listProductID();
        for (Integer value : a1) {
            clientIDComboBox.addItem(value);
        }
        for (Integer integer : a2) {
            productIDComboBox.addItem(integer);
        }

        //add components
        add (orderIDLabel);
        add (orderIDTxtField);
        add (clientIDLabel);
        add (clientIDComboBox);
        add (productIDLabel);
        add (productIDComboBox);
        add (quantityLabel);
        add (quantityTxtField);
        add (orderTxtArea);
        add (showTableButton);
        add (insertButton);
        add (generateBillButton);
        add (backButton);
        add (clearButton);
        add (cityLabel);
        add (cityTxtField);
        add (streetLabel);
        add (streetTxtField);

        //set component bounds (only needed by Absolute Positioning)
        orderIDLabel.setBounds (10, 20, 70, 25);
        orderIDTxtField.setBounds (85, 20, 100, 25);
        clientIDLabel.setBounds (10, 60, 90, 25);
        clientIDComboBox.setBounds (85, 60, 135, 25);
        productIDLabel.setBounds (10, 100, 70, 25);
        productIDComboBox.setBounds (85, 100, 100, 25);
        quantityLabel.setBounds (10, 140, 70, 25);
        quantityTxtField.setBounds (85, 140, 100, 25);
        orderTxtArea.setBounds (5, 240, 740, 300);
        showTableButton.setBounds (400, 20, 100, 25);
        insertButton.setBounds (565, 20, 100, 25);
        generateBillButton.setBounds (450, 120, 150, 25);
        backButton.setBounds (565, 70, 100, 25);
        clearButton.setBounds (400, 70, 100, 25);
        cityLabel.setBounds (10, 175, 40, 25);
        cityTxtField.setBounds (85, 175, 155, 25);
        streetLabel.setBounds (10, 210, 50, 25);
        streetTxtField.setBounds (85, 210, 155, 25);
    }

    /**
     * @return id of the order introduced in the corresponding text field
     */
    public JTextField getOrderIDTxtField() {
        return orderIDTxtField;
    }

    /**
     * @return id of the client chose in the combo box
     */
    public int getClientID() {
        return (Integer) clientIDComboBox.getSelectedItem();
    }

    /**
     * @return id of the product chose in the combo box
     */
    public int getProductID() {
        return (Integer) productIDComboBox.getSelectedItem();
    }

    /**
     * @return quantity of the product ordered, introduced in the corresponding text field
     */
    public JTextField getQuantityTxtField() {
        return quantityTxtField;
    }

    /**
     * @return city introduced in the corresponding text field
     */
    public JTextField getCityTxtField() {
        return cityTxtField;
    }

    /**
     * @return street introduced in the corresponding text field
     */
    public JTextField getStreetTxtField() {
        return streetTxtField;
    }

    /**
     * @param e action performed
     *
     * The method adds the listener for insert button
     */
    public void addListenerInsertBtn(ActionListener e) {
        this.insertButton.addActionListener(e);
    }

    /**
     * @param e action performed
     *
     * The method adds the listener for show table button
     */
    public void addListenerShowTableBtn(ActionListener e) {
        this.showTableButton.addActionListener(e);}

    /**
     * @param e action performed
     *
     * The method generates a bill for each order in the order table
     */
    public void addListenerGenerateBillBtn(ActionListener e) {
        this.generateBillButton.addActionListener(e);
    }

    /**
     * @param e action performed
     *
     * The method adds the listener for back button
     */
    public void addListenerBackBtn(ActionListener e) {
        this.backButton.addActionListener(e);
    }

    /**
     * @param e action performed
     *
     * The method adds the listener for clear button
     */
    public void addListenerClearBtn(ActionListener e) {
        this.clearButton.addActionListener(e);
    }


}
