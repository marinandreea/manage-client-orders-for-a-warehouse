package presentation;


import dataAccess.ClientDAO;

import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import javax.swing.*;
import javax.swing.event.*;

/**
 * Class that implements the graphical user interface for managing the client table
 */
public class ClientInterface extends JFrame {
    private JLabel clientIDLabel;
    private JTextField clientIDTxtField;
    private JLabel firstNameLabel;
    private JTextField firstNameTxtField;
    private JLabel lastNameLabel;
    private JTextField lastNameTxtField;
    private JLabel emailLabel;
    private JTextField emailTxtField;
    private JLabel phoneNrLabel;
    private JTextField phoneNrTxtField;
    private JTextArea clientTxtArea;
    private JButton showTableButton;
    private JButton insertButton;
    private JButton deleteButton;
    private JButton updateButton;
    private JButton backButton;
    private JButton clearButton;

    /**
     * @param userInterface userInterface
     * @param con connection to the table client from the database
     *
     * The method establishes the connection to the client table form the database, initializes the labels, text fields and buttons,
     * sets their bounds and adds them to the frame
     */
    public ClientInterface(UserInterface userInterface, Connection con) {

        ClientInterface cInt = this;
        ClientDAO clientDAO = new ClientDAO(con, cInt);

        this.setTitle("Client Table");
        this.setSize(900, 900);
        this.setLayout((LayoutManager)null);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setVisible(true);

        //construct components
        clientIDLabel = new JLabel ("Client ID:");
        clientIDTxtField = new JTextField (5);
        firstNameLabel = new JLabel ("First Name:");
        firstNameTxtField = new JTextField (5);
        lastNameLabel = new JLabel ("Last Name:");
        lastNameTxtField = new JTextField (5);
        emailLabel = new JLabel ("Email:");
        emailTxtField = new JTextField (5);
        phoneNrLabel = new JLabel ("Phone Number:");
        phoneNrTxtField = new JTextField (5);
        clientTxtArea = new JTextArea (5, 5);
        showTableButton = new JButton ("Show Table");
        insertButton = new JButton ("Insert");
        deleteButton = new JButton ("Delete");
        updateButton = new JButton ("Update");
        backButton = new JButton ("Back");
        clearButton = new JButton ("Clear");

        //adjust size and set layout
        setPreferredSize (new Dimension (752, 457));
        setLayout (null);

        //add components
        add (clientIDLabel);
        add (clientIDTxtField);
        add (firstNameLabel);
        add (firstNameTxtField);
        add (lastNameLabel);
        add (lastNameTxtField);
        add (emailLabel);
        add (emailTxtField);
        add (phoneNrLabel);
        add (phoneNrTxtField);
        add (clientTxtArea);
        add (showTableButton);
        add (insertButton);
        add (deleteButton);
        add (updateButton);
        add (backButton);
        add (clearButton);

        //set component bounds (only needed by Absolute Positioning)
        clientIDLabel.setBounds (10, 20, 60, 25);
        clientIDTxtField.setBounds (80, 20, 100, 25);
        firstNameLabel.setBounds (10, 60, 70, 25);
        firstNameTxtField.setBounds (80, 60, 100, 25);
        lastNameLabel.setBounds (10, 100, 70, 25);
        lastNameTxtField.setBounds (80, 100, 100, 25);
        emailLabel.setBounds (10, 140, 70, 25);
        emailTxtField.setBounds (80, 140, 260, 25);
        phoneNrLabel.setBounds (10, 180, 100, 25);
        phoneNrTxtField.setBounds (105, 180, 135, 25);
        clientTxtArea.setBounds (10, 215, 735, 235);
        showTableButton.setBounds (400, 20, 100, 25);
        insertButton.setBounds (565, 20, 100, 25);
        deleteButton.setBounds (400, 70, 100, 25);
        updateButton.setBounds (565, 70, 100, 25);
        backButton.setBounds (565, 120, 100, 25);
        clearButton.setBounds (400, 120, 100, 25);
    }

    /**
     * @return id of the client introduced in the corresponding text field
     */
    public JTextField getClientIDTxtField() {
        return clientIDTxtField;
    }

    /**
     * @return first name of the client introduced in the corresponding text field
     */
    public JTextField getFirstNameTxtField() {
        return firstNameTxtField;
    }

    /**
     * @return last name of the client introduced in the corresponding text field
     */
    public JTextField getLastNameTxtField() {
        return lastNameTxtField;
    }

    /**
     * @return email of the client introduced in the corresponding text field
     */
    public JTextField getEmailTxtField() {
        return emailTxtField;
    }

    /**
     * @return phone number of the client introduced in the corresponding text field
     */
    public JTextField getPhoneNrTxtField() {
        return phoneNrTxtField;
    }

    /**
     * @param e action performed
     *
     * The method adds the listener for insert button
     */
    public void addListenerInsertBtn(ActionListener e) {
        this.insertButton.addActionListener(e);
    }

    /**
     * @param e action performed
     *
     * The method adds the listener for delete button
     */
    public void addListenerDeleteBtn(ActionListener e) {
        this.deleteButton.addActionListener(e);
    }

    /**
     * @param e action performed
     *
     * The method adds the listener for update button
     */
    public void addListenerUpdateBtn(ActionListener e) {
        this.updateButton.addActionListener(e);
    }

    /**
     * @param e action performed
     *
     * The method adds the listener for show table button
     */
    public void addListenerShowTableBtn(ActionListener e) {
        this.showTableButton.addActionListener(e);}

    /**
     * @param e action performed
     *
     * The method adds the listener for back button
     */
    public void addListenerBackBtn(ActionListener e) {
        this.backButton.addActionListener(e);
    }

    /**
     * @param e action performed
     *
     * The method adds the listener for clear button
     */
    public void addListenerClearBtn(ActionListener e) {
        this.clearButton.addActionListener(e);
    }
}
