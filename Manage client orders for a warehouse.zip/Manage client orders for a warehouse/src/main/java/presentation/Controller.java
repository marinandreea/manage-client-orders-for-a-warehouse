package presentation;

import connection.ConnectionFactory;
import dataAccess.ClientDAO;
import dataAccess.OrderDAO;
import dataAccess.ProductDAO;
import model.Ord;
import model.Product;
import model.Client;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * The class controls the data flow into a model object and updates the view whenever data changes
 */
public class Controller {

    UserInterface userInterface;
    ClientInterface clientInterface;
    ProductInterface productInterface;
    OrInterface orInterface;

    /**
     * @param userInterface userInterface
     * @param clientInterface clientInterface
     * @param productInterface productInterface
     * @param orInterface orderInterface
     *
     * The constructor establishes the connection to the database and calls the method initializeButtonsUserInterface
     */
    public Controller(UserInterface userInterface, ClientInterface clientInterface, ProductInterface productInterface, OrInterface orInterface){
        Connection connection = ConnectionFactory.getConnection();
        if(connection != null){
            System.out.println("Connected!");
        }

        this.userInterface = userInterface;
        this.clientInterface = clientInterface;
        this.productInterface = productInterface;
        this.orInterface = orInterface;

        initializeButtonsUserInterface(connection);

    }

    /**
     * @param connection connection to the database
     *
     * The method initializes the three buttons form the userInterface: "Manage Client Table", "Manage ProductTable", "Manage Order Table"
     */
    public void initializeButtonsUserInterface(Connection connection){

        userInterface.addListenerClientBtn(new ActionListener() {
            /**
             * @param e click on the Manage Client Table button
             *
             * The method calls initializeButtonsClientTable which initialized the buttons from the clientInterface
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                userInterface.setVisible(false);
                clientInterface.setVisible(true);
                initializeButtonsClientTable(clientInterface, connection);
            }
        });

        userInterface.addListenerProductBtn(new ActionListener() {
            /**
             * @param e click on the Manage Product Table button
             *
             * The method calls initializeButtonsProductTable which initialized the buttons from the productInterface
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                userInterface.setVisible(false);
                productInterface.setVisible(true);
                initializeButtonsProductTable(productInterface, connection);
            }
        });

        userInterface.addListenerOrderBtn(new ActionListener() {
            /**
             * @param e click on the Manage Order Table button
             *
             * The method calls initializeButtonsOrderTable which initialized the buttons from the orderInterface
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                userInterface.setVisible(false);
                orInterface.setVisible(true);
                initializeButtonsOrderTable(orInterface, connection);
            }
        });

    }

    /**
     * @param clientInterface clientInterface
     * @param connection connection to the client table from the database
     */
    public void initializeButtonsClientTable(ClientInterface clientInterface, Connection connection){

        clientInterface.addListenerInsertBtn(new ActionListener() {
            /**
             * @param e click on the insert button
             *
             * The method calls the insertClient method from ClientDAO
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                ClientDAO clientDAO = new ClientDAO(connection,clientInterface);
                try {
                    clientDAO.insertClient();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });

        clientInterface.addListenerDeleteBtn(new ActionListener() {
            /**
             * @param e click on the delete button
             *
             * The method calls the deleteClient method from ClientDAO
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                ClientDAO clientDAO = new ClientDAO(connection,clientInterface);
                try {
                    clientDAO.deleteClient();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });

        clientInterface.addListenerUpdateBtn(new ActionListener() {
            /**
             * @param e click on the update button
             *
             * The method calls the updateClient method from ClientDAO
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                ClientDAO clientDAO = new ClientDAO(connection,clientInterface);
                try {
                    clientDAO.updateClient();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });

        clientInterface.addListenerShowTableBtn(new ActionListener() {
            /**
             * @param e click on the show table button
             *
             * The method calls the printClients method from ClientDAO
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                ClientDAO clientDAO = new ClientDAO(connection,clientInterface);
                try {
                    clientDAO.printClients();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });

        clientInterface.addListenerBackBtn(new ActionListener() {
            /**
             * @param e click on the back button
             *
             * The method takes the user back to the main window (userInterface)
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                clientInterface.setVisible(false);
                userInterface.setVisible(true);
            }
        });

        clientInterface.addListenerClearBtn(new ActionListener() {
            /**
             * @param e click on the clear button
             *
             * The method clears all the text fields
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                clientInterface.getClientIDTxtField().setText("");
                clientInterface.getFirstNameTxtField().setText("");
                clientInterface.getLastNameTxtField().setText("");
                clientInterface.getEmailTxtField().setText("");
                clientInterface.getPhoneNrTxtField().setText("");
            }
        });

    }

    /**
     * @param productInterface productInterface
     * @param connection connection to the product table from the database
     */
    public void initializeButtonsProductTable(ProductInterface productInterface, Connection connection){

        productInterface.addListenerInsertBtn(new ActionListener() {
            /**
             * @param e click on the insert button
             *
             * The method calls the insertProduct method from ProductDAO
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                ProductDAO productDAO = new ProductDAO(connection,productInterface);
                try {
                    productDAO.insertProduct();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });

        productInterface.addListenerDeleteBtn(new ActionListener() {
            /**
             * @param e click on the delete button
             *
             * The method calls the deleteProduct method from ProductDAO
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                ProductDAO productDAO = new ProductDAO(connection,productInterface);
                try {
                    productDAO.deleteProduct();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });

        productInterface.addListenerUpdateBtn(new ActionListener() {
            /**
             * @param e click on the update button
             *
             * The method calls the updateProduct method from ProductDAO
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                ProductDAO productDAO = new ProductDAO(connection,productInterface);
                try {
                    productDAO.updateProduct();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });

        productInterface.addListenerShowTableBtn(new ActionListener() {
            /**
             * @param e click on the show table button
             *
             * The method calls the printProducts method from ProductDAO
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                ProductDAO productDAO = new ProductDAO(connection,productInterface);
                try {
                    productDAO.printProducts();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });

        productInterface.addListenerBackBtn(new ActionListener() {
            /**
             * @param e click on the back button
             *
             * The method takes the user back to the main window (userInterface)
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                productInterface.setVisible(false);
                userInterface.setVisible(true);
            }
        });

        productInterface.addListenerClearBtn(new ActionListener() {
            /**
             * @param e click on the clear button
             *
             * The method clears all the text fields
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                productInterface.getProductIDTxtField().setText("");
                productInterface.getProductNameTxtField().setText("");
                productInterface.getPriceTxtField().setText("");
                productInterface.getStockTxtField().setText("");
            }
        });

    }

    /**
     * @param orInterface orderInterface
     * @param connection connection to the order table from the database
     */
    public void initializeButtonsOrderTable(OrInterface orInterface, Connection connection){

        orInterface.addListenerInsertBtn(new ActionListener() {
            /**
             * @param e click on the insert button
             *
             * The method calls the createOrder method from OrderDAO
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                OrderDAO orderDAO = new OrderDAO(connection, orInterface, productInterface);
                try {
                    orderDAO.createOrder();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });

        orInterface.addListenerShowTableBtn(new ActionListener() {
            /**
             * @param e click on the show table button
             *
             * The method calls the printOrders method from OrderDAO
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                OrderDAO orderDAO = new OrderDAO(connection, orInterface, productInterface);
                try {
                    orderDAO.printOrders();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });

        orInterface.addListenerBackBtn(new ActionListener() {
            /**
             * @param e click on the back button
             *
             * The method takes the user back to the main window (userInterface)
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                orInterface.setVisible(false);
                userInterface.setVisible(true);
            }
        });

        orInterface.addListenerClearBtn(new ActionListener() {
            /**
             * @param e click on the clear button
             *
             * The method clears all the text fields
             */
            @Override
            public void actionPerformed(ActionEvent e) {
             orInterface.getOrderIDTxtField().setText("");
             orInterface.getCityTxtField().setText("");
             orInterface.getQuantityTxtField().setText("");
             orInterface.getStreetTxtField().setText("");
            }
        });

        orInterface.addListenerGenerateBillBtn(new ActionListener() {
            /**
             * @param e click on the generate bill button
             *
             * The method builds a string containing the bill for each order in the order table and writes that string in the GeneratedBill.txt file
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                OrderDAO orderDAO = new OrderDAO(connection, orInterface, productInterface);
                File file = new File("GeneratedBill.txt");
                try {
                    file.createNewFile();
                    BufferedWriter writer = new BufferedWriter(new FileWriter(file.getName()));
                    StringBuilder stringBuilder = new StringBuilder();
                    ArrayList<Ord> orders = new ArrayList<Ord>();
                    orders = orderDAO.orderArray();

                    for(Ord o: orders){
                       stringBuilder.append("Order: " + o.getOrderID() +";"+"\n");
                       int clientID = o.getClientId();
                       int productID = o.getProductId();
                       ClientDAO clientDAO = new ClientDAO(connection,clientInterface);
                       ArrayList<Client> clients = clientDAO.clientArray();
                       Client cl = null;
                       for(Client c: clients){
                           if(c.getClientID() == clientID){
                               cl = c;
                           }
                       }
                       if(cl != null){
                           stringBuilder.append("First Name: "+cl.getFirstName()+";"+"\n");
                           stringBuilder.append("Last Name: "+cl.getLastName()+";"+"\n");
                       }
                       ProductDAO productDAO = new ProductDAO(connection,productInterface);
                       ArrayList<Product> products = new ArrayList<Product>();
                       products = productDAO.prodArray();
                       Product pr = null;
                       for(Product p: products){
                           if(p.getProductID() == productID){
                               pr = p;
                           }
                       }
                       if(pr != null){
                           stringBuilder.append("Product: "+pr.getProductName()+";"+"\n");

                           stringBuilder.append("Quantity: "+o.getQuantity()+";"+"\n");
                           double price = o.getQuantity() * pr.getPrice();
                           stringBuilder.append("Total price: "+price+";"+"\n");

                       }else{
                           stringBuilder.append("Product: out of stock"+"\n");
                       }

                       writer.write(stringBuilder.toString());
                       writer.write("\n");
                       stringBuilder.delete(0,stringBuilder.length());
                    }
                    writer.flush();
                    writer.close();
                } catch (IOException | SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });
    }
}
