package businessLogic;

/**
 * Class that contains methods for validating the order's data introduced in the text fields
 */
public class ValidatorOrder {

    /**
     * Default constructor
     */
    public ValidatorOrder(){

    }

    /**
     * @param quantity quantity of the ordered product
     * @return 1 if the quantity is validated and 0 otherwise
     */
    public int validateQuantity(int quantity){
        if(quantity < 0){
            return 0;
        }
        return 1;
    }

    /**
     * @param s city or street for delivering the order
     * @return 1 if the city or street is validated and 0 otherwise
     */
    public int validateCityAndStreet(String s){
        if (s == "")
            return 0;
        if (s.matches("[A-Z][a-z]+") == false)
            return 0;
        return 1;
    }

    /**
     * @param quantity quantity of the ordered product
     * @param city city to deliver the order
     * @param street street to deliver the order
     * @return true if the data is validated and false otherwise
     */
    public boolean validateOrder(int quantity, String city, String street){
        if(validateQuantity(quantity) == 0 || validateCityAndStreet(city) == 0 || validateCityAndStreet(street) == 0){
            return false;
        }
        return true;
    }

}
