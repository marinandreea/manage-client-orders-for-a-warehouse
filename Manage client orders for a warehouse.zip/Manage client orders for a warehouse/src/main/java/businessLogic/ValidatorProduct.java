package businessLogic;

/**
 * Class that contains methods for validating the product's data introduced in the text fields
 */
public class ValidatorProduct {

    /**
     * Default constructor
     */
    public ValidatorProduct(){

    }

    /**
     * @param name name of the product
     * @return 1 if the name of the product is validated and 0 otherwise
     */
    public int validateName(String name){
        if(name.equals(" ")){
            return 0;
        }
        if(name.matches("[a-z]+") == false){
            return 0;
        }
        return 1;
    }

    /**
     * @param price price of the product
     * @return 1 if the price is validated and 0 otherwise
     */
    public int validatePrice(double price){
        if(price < 0){
            return 0;
        }
        return 1;
    }

    /**
     * @param stock stock of the product
     * @return 1 if the stock is validated and 0 otherwise
     */
    public int validateStock(int stock){
        if(stock < 0){
            return 0;
        }
        return 1;
    }

    /**
     * @param name name of the product
     * @param price price of the product
     * @param stock stock of the product
     * @return true if the data is validated and false otherwise
     */
    public boolean validateProduct(String name, double price, int stock){
        if(validateName(name) == 0 || validatePrice(price) == 0 || validateStock(stock) == 0){
            return false;
        }
        return true;
    }
}
